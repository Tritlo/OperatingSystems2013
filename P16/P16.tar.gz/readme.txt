Project by Haukur Óskar Þorgeirsson (hth152@hi.is) and Matthías Páll Gissurarson (mpg3@hi.is)

To start part Two, you can run "make test" to test for 10000, or RaceThreadsMonitorSemaphore N where N is the number you want them to go count up to.
